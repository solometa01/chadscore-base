export type Rank = 'noob' | 'chad' | 'giga';

export interface WalletMetrics {
  age: number; // days
  tx: number; // total transactions
  defi: number; // 0-100 DeFi activity score
  nft: number; // NFTs held
  risk: number; // 0-100, lower is safer
}

export interface ChadProfile {
  address: string;
  metrics: WalletMetrics;
  score: number;
  rank: Rank;
}

export interface Badge {
  id: string;
  icon: string;
  name: string;
  test: (m: WalletMetrics, score: number) => boolean;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  xp: number;
  difficulty: 'easy' | 'medium' | 'hard';
  done: boolean;
}

export interface RadarToken {
  icon: string;
  name: string;
  tag: string;
  change24h: number;
  hype: number;
}

export interface TopChad {
  name: string;
  score: number;
  metrics: WalletMetrics;
}

export interface LeaderboardEntry {
  name: string;
  score: number;
  level: number;
  isYou: boolean;
}
