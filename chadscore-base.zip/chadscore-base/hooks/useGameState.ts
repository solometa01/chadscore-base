'use client';

import { useEffect, useState } from 'react';
import type { ChadProfile, Quest } from '@/types';
import { BADGE_DEFS } from '@/lib/mockData';
import { fetchAiQuests } from '@/lib/ai';

const XP_PER_LEVEL = 150;

export function useGameState(profile: ChadProfile | null) {
  const [xp, setXp] = useState(0);
  const [quests, setQuests] = useState<Quest[]>([]);
  const [scanned, setScanned] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [minted, setMinted] = useState(false);

  // reset the session whenever the connected wallet changes
  useEffect(() => {
    if (!profile) return;
    setXp(20 + Math.round(profile.score / 2));
    setQuests([]);
    setScanned(false);
    setMinted(false);
  }, [profile?.address]);

  const level = Math.floor(xp / XP_PER_LEVEL) + 1;
  const xpIntoLevel = xp % XP_PER_LEVEL;
  const badges = profile ? BADGE_DEFS.filter((b) => b.test(profile.metrics, profile.score)) : [];

  async function scanSocials() {
    if (!profile) return;
    setScanning(true);
    // simulated social scan delay — swap for a real X/Telegram API call
    await new Promise((r) => setTimeout(r, 2200));
    const generated = await fetchAiQuests(profile.metrics, profile.score, profile.rank);
    setQuests(generated.map((q, i) => ({ ...q, id: `q${i}`, done: false })));
    setScanning(false);
    setScanned(true);
  }

  function completeQuest(id: string) {
    setQuests((prev) => {
      const target = prev.find((q) => q.id === id);
      if (!target || target.done) return prev;
      setXp((x) => x + target.xp);
      return prev.map((q) => (q.id === id ? { ...q, done: true } : q));
    });
  }

  function mintBadge() {
    setMinted(true);
  }

  return {
    xp,
    xpIntoLevel,
    xpPerLevel: XP_PER_LEVEL,
    level,
    badges,
    quests,
    scanned,
    scanning,
    minted,
    scanSocials,
    completeQuest,
    mintBadge,
  };
}
