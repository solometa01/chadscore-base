'use client';

import { useMemo } from 'react';
import { useAccount } from 'wagmi';
import { generateMetrics } from '@/lib/mockData';
import { computeScore, rankFromScore } from '@/lib/score';
import type { ChadProfile } from '@/types';

/**
 * Derives a full ChadProfile (metrics, score, rank) from the connected
 * wallet address. Metrics are deterministically mocked from the address —
 * swap generateMetrics() for real on-chain reads / a backend indexer call
 * when wiring this up to production data.
 */
export function useChadProfile(): ChadProfile | null {
  const { address, isConnected } = useAccount();

  return useMemo(() => {
    if (!isConnected || !address) return null;
    const metrics = generateMetrics(address);
    const score = computeScore(metrics);
    const rank = rankFromScore(score);
    return { address, metrics, score, rank };
  }, [address, isConnected]);
}
