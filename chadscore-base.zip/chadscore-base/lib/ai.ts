import type { WalletMetrics, Rank } from '@/types';
import { fallbackQuests, fallbackSummary } from '@/lib/mockData';
import { rankLabel } from '@/lib/score';

export async function fetchAiSummary(metrics: WalletMetrics, score: number, rank: Rank): Promise<string> {
  try {
    const res = await fetch('/api/ai-summary', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ metrics, score, rank: rankLabel(rank) }),
    });
    const data = await res.json();
    if (data?.text) return data.text as string;
  } catch {
    // fall through to local fallback
  }
  return fallbackSummary(metrics, score, rank);
}

export interface GeneratedQuest {
  title: string;
  description: string;
  xp: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

export async function fetchAiQuests(metrics: WalletMetrics, score: number, rank: Rank): Promise<GeneratedQuest[]> {
  try {
    const res = await fetch('/api/ai-quests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ metrics, score, rank: rankLabel(rank) }),
    });
    const data = await res.json();
    if (Array.isArray(data?.quests) && data.quests.length > 0) {
      return data.quests.slice(0, 4) as GeneratedQuest[];
    }
  } catch {
    // fall through to local fallback
  }
  return fallbackQuests();
}
