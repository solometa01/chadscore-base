import type { Rank, WalletMetrics } from '@/types';

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

/**
 * Weighted 0-100 ChadScore.
 * age 20% · tx count 25% · defi activity 25% · nft holdings 15% · safety (100-risk) 15%
 */
export function computeScore(m: WalletMetrics): number {
  const ageScore = clamp(m.age / 730, 0, 1) * 100; // 2 years = maxed
  const txScore = clamp(m.tx / 1200, 0, 1) * 100;
  const defiScore = m.defi;
  const nftScore = clamp(m.nft / 50, 0, 1) * 100;
  const safetyScore = 100 - m.risk;

  const raw =
    ageScore * 0.2 + txScore * 0.25 + defiScore * 0.25 + nftScore * 0.15 + safetyScore * 0.15;

  return Math.round(clamp(raw, 0, 100));
}

export function rankFromScore(score: number): Rank {
  if (score >= 75) return 'giga';
  if (score >= 40) return 'chad';
  return 'noob';
}

export function rankLabel(rank: Rank): string {
  if (rank === 'giga') return 'GIGACHAD';
  if (rank === 'chad') return 'CHAD';
  return 'NOOB';
}

export function rankColor(rank: Rank): string {
  if (rank === 'giga') return '#FFB800';
  if (rank === 'chad') return '#00D67F';
  return '#0052FF';
}
