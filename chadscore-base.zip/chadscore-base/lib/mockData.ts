import type { Badge, RadarToken, TopChad, WalletMetrics } from '@/types';

/** Simple string hash -> 32-bit seed, so the same address always gets the same metrics. */
function hashString(str: string): number {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}

/** Mulberry32 PRNG — deterministic, fast, good enough for mock data. */
function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function rndInt(rand: () => number, min: number, max: number) {
  return Math.floor(rand() * (max - min + 1)) + min;
}

/**
 * Deterministically derives wallet metrics from an address. Same wallet
 * always gets the same ChadScore on reload — swap this out for real
 * on-chain reads (tx count, protocol interactions, NFT balances, a risk
 * oracle, etc.) when wiring up production data sources.
 */
export function generateMetrics(address: string): WalletMetrics {
  const rand = mulberry32(hashString(address.toLowerCase()));
  return {
    age: rndInt(rand, 20, 1400),
    tx: rndInt(rand, 15, 4800),
    defi: rndInt(rand, 5, 98),
    nft: rndInt(rand, 0, 140),
    risk: rndInt(rand, 3, 90),
  };
}

export const BADGE_DEFS: Badge[] = [
  { id: 'connect', icon: '🔌', name: 'First connect', test: () => true },
  { id: 'og', icon: '🕰️', name: 'OG wallet', test: (m) => m.age > 365 },
  { id: 'degen', icon: '🌀', name: 'DeFi degen', test: (m) => m.defi >= 70 },
  { id: 'collector', icon: '🖼️', name: 'NFT collector', test: (m) => m.nft >= 20 },
  { id: 'safehands', icon: '🛡️', name: 'Safe hands', test: (m) => m.risk <= 20 },
  { id: 'giga', icon: '🐐', name: 'Gigachad', test: (_m, score) => score >= 75 },
];

export const TOP_CHADS: TopChad[] = [
  { name: '0xGigaWhale.base', score: 97, metrics: { age: 920, tx: 4200, defi: 96, nft: 88, risk: 6 } },
  { name: 'basedmaxi.eth', score: 91, metrics: { age: 760, tx: 3100, defi: 88, nft: 70, risk: 10 } },
  { name: 'DegenApeLord', score: 86, metrics: { age: 640, tx: 2600, defi: 82, nft: 95, risk: 14 } },
  { name: 'onchain_ogre', score: 79, metrics: { age: 510, tx: 1900, defi: 75, nft: 55, risk: 18 } },
  { name: 'wagmi_wendy', score: 74, metrics: { age: 430, tx: 1500, defi: 68, nft: 60, risk: 22 } },
];

const RADAR_SEED: Omit<RadarToken, 'hype'>[] = [
  { icon: '🔵', name: 'Aerodrome', tag: 'DeFi', change24h: 8.4 },
  { icon: '🎩', name: 'Based Punks', tag: 'NFT', change24h: 14.2 },
  { icon: '🐸', name: 'DEGEN', tag: 'Meme', change24h: -6.1 },
  { icon: '⚙️', name: 'Moonwell', tag: 'Lending', change24h: 3.7 },
  { icon: '🌉', name: 'Friend.tech v2', tag: 'SocialFi', change24h: -2.3 },
  { icon: '🧬', name: 'BasePaint', tag: 'NFT', change24h: 5.9 },
];

/** Trending Base tokens/apps. Swap for a real Dexscreener/Defillama feed in production. */
export function generateRadar(): RadarToken[] {
  return RADAR_SEED.map((t) => ({
    ...t,
    change24h: Math.round((t.change24h + (Math.random() * 4 - 2)) * 10) / 10,
    hype: rndInt(Math.random, 40, 98),
  }));
}

export function fallbackQuests() {
  return [
    { title: 'Bridge to Base', description: 'Bridge at least 0.01 ETH to Base and complete your first swap.', xp: 40, difficulty: 'easy' as const },
    { title: 'Ape a new DeFi pool', description: 'Provide liquidity or stake in a Base-native protocol this week.', xp: 65, difficulty: 'medium' as const },
    { title: 'Mint an NFT collection', description: 'Mint from a trending Base NFT drop to grow your bag.', xp: 55, difficulty: 'medium' as const },
    { title: 'Post your ChadScore', description: 'Share your ChadScore on X and tag two friends to flex.', xp: 25, difficulty: 'easy' as const },
  ];
}

export function fallbackSummary(m: WalletMetrics, score: number, rank: 'noob' | 'chad' | 'giga') {
  const lines: Record<string, string> = {
    noob: `Still stacking blocks of experience. ${m.tx} txs and ${m.age} days in — the wallet's got potential but risk sits at ${m.risk}. Ape a little more, ser.`,
    chad: `Solid on-chain presence: ${m.tx} txs, DeFi score ${m.defi}, ${m.nft} NFTs in the bag. Not quite gigachad but the wallet's clearly wagmi-pilled.`,
    giga: `Absolute unit of a wallet. ${m.age} days deep, DeFi maxed at ${m.defi}, risk kept tight at ${m.risk}. This is what diamond hands look like on-chain.`,
  };
  return lines[rank];
}
