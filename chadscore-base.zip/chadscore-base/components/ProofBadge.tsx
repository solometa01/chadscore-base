'use client';

import { useState } from 'react';
import type { ChadProfile } from '@/types';
import { rankLabel } from '@/lib/score';

function randomHash() {
  const chars = '0123456789abcdef';
  let h = '0x';
  for (let i = 0; i < 64; i++) h += chars[Math.floor(Math.random() * 16)];
  return h;
}

export function ProofBadge({ profile, minted, onMint }: { profile: ChadProfile; minted: boolean; onMint: () => void }) {
  const [minting, setMinting] = useState(false);
  const [hash, setHash] = useState('');

  async function handleMint() {
    if (minted || minting) return;
    setMinting(true);
    await new Promise((r) => setTimeout(r, 1200));
    setHash(randomHash());
    setMinting(false);
    onMint();
  }

  const emoji = profile.rank === 'giga' ? '🐐' : profile.rank === 'chad' ? '💪' : '🔒';

  return (
    <div
      className="rounded-2xl border border-gold p-6 text-center"
      style={{ backgroundImage: 'linear-gradient(160deg,#FFB80014,transparent 50%)', background: '#10151F' }}
    >
      <div
        className="mx-auto mb-3 flex h-[84px] w-[84px] items-center justify-center rounded-2xl border-2 border-gold text-4xl"
        style={{ background: 'radial-gradient(circle at 30% 25%,#3a2c00,#0c0c0c 70%)' }}
      >
        {emoji}
      </div>
      <h3 className="mb-1 text-base font-medium">
        {rankLabel(profile.rank)} · Score {profile.score}
      </h3>
      <p className="mb-4 text-xs text-ink-faint">
        A non-transferable badge minted to your wallet, permanently tied to this score.
      </p>
      <button
        onClick={handleMint}
        disabled={minted || minting}
        className="w-full rounded-xl bg-gold px-4 py-3.5 text-[15px] font-semibold text-[#231600] disabled:opacity-70"
      >
        {minted ? 'Badge minted ✓' : minting ? 'Minting...' : 'Mint proof badge'}
      </button>
      {(minted || hash) && (
        <div className="mt-3 break-all rounded-lg bg-panel2 p-2.5 text-[11px] text-chadgreen">
          Minted (non-transferable) · tx {hash.slice(0, 18)}...
        </div>
      )}
    </div>
  );
}
