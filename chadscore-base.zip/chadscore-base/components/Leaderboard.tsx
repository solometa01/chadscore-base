'use client';

import { useMemo } from 'react';
import type { ChadProfile } from '@/types';
import { TOP_CHADS } from '@/lib/mockData';

function shortAddr(a: string) {
  return a.slice(0, 6) + '...' + a.slice(-4);
}

export function Leaderboard({ profile, level }: { profile: ChadProfile; level: number }) {
  const entries = useMemo(() => {
    const list = TOP_CHADS.map((c, i) => ({
      name: c.name,
      score: c.score,
      level: 2 + ((i * 3) % 8),
      isYou: false,
    }));
    list.push({ name: shortAddr(profile.address), score: profile.score, level, isYou: true });
    return list.sort((a, b) => b.score - a.score);
  }, [profile.address, profile.score, level]);

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-base font-medium">Leaderboard</h2>
        <span className="text-xs text-ink-faint">top Base wallets</span>
      </div>
      <div className="rounded-2xl border border-line bg-panel px-4">
        {entries.map((e, i) => (
          <div
            key={e.name}
            className={`flex items-center gap-3 py-3 ${i !== entries.length - 1 ? 'border-b border-line' : ''} ${
              e.isYou ? '-mx-4 rounded-xl bg-base-dim px-4' : ''
            }`}
          >
            <div className="w-6 flex-shrink-0 text-center text-[13px] font-bold text-ink-faint">{i + 1}</div>
            <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-panel2 text-sm">
              {e.isYou ? '🦍' : '🐐'}
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-mono text-[13.5px] font-semibold">
                {e.name}
                {e.isYou && <span className="ml-1.5 text-[9.5px] font-bold text-base">YOU</span>}
              </div>
              <div className="text-[11px] text-ink-faint">Level {e.level}</div>
            </div>
            <div className="font-display text-[15px] font-bold">{e.score}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
