'use client';

import { useState } from 'react';
import type { ChadProfile } from '@/types';
import { TOP_CHADS } from '@/lib/mockData';

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

export function SmartCompare({ profile }: { profile: ChadProfile }) {
  const [oppIndex, setOppIndex] = useState(0);
  const opp = TOP_CHADS[oppIndex];
  const m = profile.metrics;

  const rows = [
    { label: 'Wallet age', you: clamp((m.age / 1400) * 100, 0, 100), opp: clamp((opp.metrics.age / 1400) * 100, 0, 100) },
    { label: 'Total txs', you: clamp((m.tx / 4800) * 100, 0, 100), opp: clamp((opp.metrics.tx / 4800) * 100, 0, 100) },
    { label: 'DeFi score', you: m.defi, opp: opp.metrics.defi },
    { label: 'NFT holdings', you: clamp((m.nft / 140) * 100, 0, 100), opp: clamp((opp.metrics.nft / 140) * 100, 0, 100) },
    { label: 'Safety', you: 100 - m.risk, opp: 100 - opp.metrics.risk },
  ];

  const diff = opp.score - profile.score;

  return (
    <div>
      <div className="mb-3">
        <h2 className="text-base font-medium">Smart compare</h2>
      </div>
      <select
        value={oppIndex}
        onChange={(e) => setOppIndex(Number(e.target.value))}
        className="mb-4 w-full appearance-none rounded-xl border border-line bg-panel2 px-3.5 py-3 text-sm"
      >
        {TOP_CHADS.map((c, i) => (
          <option key={c.name} value={i}>
            {c.name} ({c.score})
          </option>
        ))}
      </select>

      <div className="rounded-2xl border border-line bg-panel p-4">
        <div className="mb-4 flex gap-4 text-xs text-ink-dim">
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-2.5 rounded-sm bg-base" /> You
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-2.5 rounded-sm bg-gold" /> {opp.name}
          </span>
        </div>

        {rows.map((r) => (
          <div key={r.label} className="mb-3.5">
            <div className="mb-1.5 text-xs text-ink-dim">{r.label}</div>
            <div className="relative h-4">
              <div className="absolute inset-0 rounded-md bg-panel2" />
              <div className="absolute left-0 top-0 h-1.5 rounded-md bg-base" style={{ width: `${r.you}%` }} />
              <div className="absolute bottom-0 left-0 h-1.5 rounded-md bg-gold" style={{ width: `${r.opp}%` }} />
            </div>
          </div>
        ))}

        <div className="mt-4 border-t border-line pt-3.5 text-[13.5px] leading-relaxed text-ink-dim">
          {diff <= 0 ? (
            <>
              <b className="text-ink">You're ahead!</b> Your ChadScore beats {opp.name} by {Math.abs(diff)} points.
              Keep grinding to hold the lead.
            </>
          ) : (
            <>
              You're <b className="text-ink">{diff} points</b> behind {opp.name}. Push DeFi activity and hold longer
              to close the gap.
            </>
          )}
        </div>
      </div>
    </div>
  );
}
