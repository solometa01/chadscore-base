'use client';

import { useEffect, useState } from 'react';
import type { Quest } from '@/types';

const SCAN_LOG_LINES = [
  'Reading X timeline...',
  'Checking Telegram groups...',
  'Cross-referencing on-chain activity...',
  'Detecting degen signals...',
  'Compiling quest profile...',
];

const DIFF_CLASSES: Record<string, string> = {
  easy: 'bg-chadgreen/15 text-chadgreen',
  medium: 'bg-gold/15 text-gold',
  hard: 'bg-chadred/15 text-chadred',
};

export function QuestPanel({
  scanned,
  scanning,
  quests,
  onScan,
  onComplete,
}: {
  scanned: boolean;
  scanning: boolean;
  quests: Quest[];
  onScan: () => void;
  onComplete: (id: string) => void;
}) {
  const [logIndex, setLogIndex] = useState(0);

  useEffect(() => {
    if (!scanning) {
      setLogIndex(0);
      return;
    }
    const iv = setInterval(() => setLogIndex((i) => (i + 1) % SCAN_LOG_LINES.length), 450);
    return () => clearInterval(iv);
  }, [scanning]);

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-base font-medium">AI quests</h2>
        <span className="text-xs text-ink-faint">personalized</span>
      </div>

      {!scanned && (
        <div className="rounded-2xl border border-line bg-panel p-7 text-center">
          <div className="mb-2.5 text-3xl">📡</div>
          <h3 className="mb-1.5 text-[15px] font-medium">Scan your socials</h3>
          <p className="mb-4 text-[13px] leading-relaxed text-ink-dim">
            Simulate a scan of your X and Telegram activity to generate quests tailored to your degen profile.
          </p>
          <button
            onClick={onScan}
            disabled={scanning}
            className="w-full rounded-xl bg-base px-4 py-3.5 text-[15px] font-semibold text-white disabled:opacity-60"
          >
            {scanning ? 'Scanning...' : 'Scan X + Telegram'}
          </button>
          {scanning && (
            <div className="mt-3.5 font-mono text-[11.5px] text-ink-faint">{SCAN_LOG_LINES[logIndex]}</div>
          )}
        </div>
      )}

      {scanned && (
        <div className="flex flex-col gap-3.5">
          {quests.length === 0 && (
            <div className="rounded-2xl border border-line bg-panel p-5 text-center text-[13px] text-ink-faint">
              Generating personalized quests...
            </div>
          )}
          {quests.map((q) => (
            <div
              key={q.id}
              className={`rounded-2xl border-l-[3px] border border-line bg-panel p-4 ${q.done ? 'border-l-chadgreen opacity-60' : 'border-l-base'}`}
            >
              <div className="mb-1.5 flex items-start justify-between gap-2.5">
                <div className="text-[14.5px] font-semibold">{q.title}</div>
                <div className={`whitespace-nowrap rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${DIFF_CLASSES[q.difficulty]}`}>
                  {q.difficulty}
                </div>
              </div>
              <p className="mb-3 text-[13px] leading-relaxed text-ink-dim">{q.description}</p>
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-gold">+{q.xp} XP</div>
                <button
                  onClick={() => onComplete(q.id)}
                  disabled={q.done}
                  className={`rounded-lg px-3.5 py-2 text-[13px] font-semibold ${
                    q.done ? 'border border-line text-ink-dim' : 'bg-base text-white'
                  } disabled:opacity-70`}
                >
                  {q.done ? 'Completed ✓' : 'Complete quest'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
