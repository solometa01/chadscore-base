'use client';

import { useEffect, useState } from 'react';
import type { ChadProfile } from '@/types';
import { fetchAiSummary } from '@/lib/ai';

export function AiSummary({ profile }: { profile: ChadProfile }) {
  const [text, setText] = useState('Cooking up your review...');
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    setText('Cooking up your review...');
    const result = await fetchAiSummary(profile.metrics, profile.score, profile.rank);
    setText(result);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile.address]);

  return (
    <div className="rounded-2xl border border-base-dim bg-panel p-4" style={{ backgroundImage: 'linear-gradient(180deg,#0052FF14,transparent 60%)' }}>
      <div className="mb-2.5 inline-flex items-center gap-1 rounded-full bg-base-dim px-2.5 py-1 text-[10px] font-bold tracking-wide text-base">
        ✦ AI generated
      </div>
      <p className="min-h-[60px] text-[14.5px] leading-relaxed">{text}</p>
      <div className="mt-3">
        <button
          onClick={load}
          disabled={loading}
          className="rounded-lg border border-line bg-panel2 px-3.5 py-2 text-[13px] font-semibold disabled:opacity-50"
        >
          {loading ? '↻ Thinking...' : '↻ Regenerate'}
        </button>
      </div>
    </div>
  );
}
