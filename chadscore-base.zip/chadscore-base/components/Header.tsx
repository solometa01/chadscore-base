'use client';

import { ConnectButton } from '@rainbow-me/rainbowkit';

export function Header() {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between border-b border-line bg-void/85 px-4 py-3.5 backdrop-blur-md">
      <div className="flex items-center gap-2 font-display text-lg font-bold tracking-tight">
        <span className="text-base">⚡</span>
        ChadScore
        <span className="ml-0.5 text-xs font-medium text-ink-faint">.xyz</span>
      </div>
      <ConnectButton showBalance={false} chainStatus="icon" accountStatus="address" />
    </header>
  );
}
