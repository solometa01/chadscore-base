'use client';

import { useState } from 'react';
import { generateRadar } from '@/lib/mockData';

export function DegenRadar() {
  const [tokens, setTokens] = useState(() => generateRadar());

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-base font-medium">Degen radar</h2>
        <button
          onClick={() => setTokens(generateRadar())}
          className="rounded-lg border border-line px-3 py-1.5 text-[13px] text-ink-dim"
        >
          ↻ Refresh
        </button>
      </div>
      <div className="rounded-2xl border border-line bg-panel px-4">
        {tokens.map((t, i) => (
          <div
            key={t.name}
            className={`flex items-center gap-3 py-3.5 ${i !== tokens.length - 1 ? 'border-b border-line' : ''}`}
          >
            <div className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-xl bg-panel2 text-[17px]">
              {t.icon}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-sm font-semibold">
                {t.name}
                <span className="rounded-full bg-panel2 px-1.5 py-0.5 text-[9.5px] uppercase tracking-wide text-ink-faint">
                  {t.tag}
                </span>
              </div>
              <div className="mt-1.5 h-1 overflow-hidden rounded-md bg-panel2">
                <div className="h-full bg-base" style={{ width: `${t.hype}%` }} />
              </div>
            </div>
            <div className={`flex-shrink-0 font-mono text-[13.5px] font-bold ${t.change24h >= 0 ? 'text-chadgreen' : 'text-chadred'}`}>
              {t.change24h >= 0 ? '+' : ''}
              {t.change24h.toFixed(1)}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
