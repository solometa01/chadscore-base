'use client';

export function XpBar({ level, xpIntoLevel, xpPerLevel }: { level: number; xpIntoLevel: number; xpPerLevel: number }) {
  const pct = (xpIntoLevel / xpPerLevel) * 100;

  return (
    <div className="flex items-center gap-3.5 rounded-2xl border border-line bg-panel p-4">
      <div
        className="relative h-[52px] w-[52px] flex-shrink-0 rounded-full"
        style={{ background: `conic-gradient(#FFB800 ${pct}%, #171E2C 0)` }}
      >
        <div className="absolute inset-[5px] flex items-center justify-center rounded-full bg-panel text-[15px] font-bold">
          L{level}
        </div>
      </div>
      <div>
        <div className="text-sm font-bold">Level {level}</div>
        <div className="mt-1.5 h-1.5 w-[180px] max-w-[40vw] overflow-hidden rounded-md bg-panel2">
          <div className="h-full rounded-md bg-gold" style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-1 text-[11px] text-ink-faint">
          {xpIntoLevel} / {xpPerLevel} XP
        </div>
      </div>
    </div>
  );
}
