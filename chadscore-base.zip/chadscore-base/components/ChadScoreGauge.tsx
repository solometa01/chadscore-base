'use client';

import { useEffect, useState } from 'react';
import type { Rank } from '@/types';
import { rankColor, rankLabel } from '@/lib/score';

const CIRCUMFERENCE = 302;

export function ChadScoreGauge({ score, rank }: { score: number; rank: Rank }) {
  const [displayed, setDisplayed] = useState(0);
  const offset = CIRCUMFERENCE - (CIRCUMFERENCE * score) / 100;

  useEffect(() => {
    let n = 0;
    const inc = Math.max(1, Math.round(score / 30));
    const iv = setInterval(() => {
      n = Math.min(score, n + inc);
      setDisplayed(n);
      if (n >= score) clearInterval(iv);
    }, 25);
    return () => clearInterval(iv);
  }, [score]);

  const rankClasses: Record<Rank, string> = {
    noob: 'bg-ink-faint/20 text-ink-faint',
    chad: 'bg-chadgreen/15 text-chadgreen',
    giga: 'bg-gold/15 text-gold',
  };

  return (
    <div className="flex flex-col items-center pb-1 pt-1.5">
      <svg width="220" height="130" viewBox="0 0 220 130">
        <path
          d="M 14 116 A 96 96 0 0 1 206 116"
          fill="none"
          stroke="#171E2C"
          strokeWidth="14"
          strokeLinecap="round"
        />
        <path
          d="M 14 116 A 96 96 0 0 1 206 116"
          fill="none"
          stroke={rankColor(rank)}
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s ease, stroke 0.4s ease' }}
        />
      </svg>
      <div className="-mt-11 font-display text-[52px] font-bold tracking-tight">
        {displayed}
        <small className="text-lg font-medium text-ink-faint">/100</small>
      </div>
      <div className={`mt-0.5 rounded-full px-3.5 py-1.5 text-[13px] font-bold tracking-wide ${rankClasses[rank]}`}>
        {rankLabel(rank)}
      </div>

      <div className="relative my-5 h-1.5 w-full rounded-md bg-panel2">
        <div
          className="absolute left-0 top-0 h-full rounded-md"
          style={{ width: `${score}%`, background: 'linear-gradient(90deg,#6B7480,#00D67F,#FFB800)' }}
        />
      </div>
      <div className="flex w-full justify-between text-[11px] text-ink-faint">
        <span className={rank === 'noob' ? 'font-semibold text-ink' : ''}>Noob</span>
        <span className={rank === 'chad' ? 'font-semibold text-ink' : ''}>Chad</span>
        <span className={rank === 'giga' ? 'font-semibold text-ink' : ''}>Gigachad</span>
      </div>
    </div>
  );
}
