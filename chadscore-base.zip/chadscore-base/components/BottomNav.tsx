'use client';

export type TabKey = 'score' | 'quests' | 'radar' | 'compare' | 'board';

const TABS: { key: TabKey; icon: string; label: string }[] = [
  { key: 'score', icon: '🎯', label: 'Score' },
  { key: 'quests', icon: '🗺️', label: 'Quests' },
  { key: 'radar', icon: '📡', label: 'Radar' },
  { key: 'compare', icon: '⚖️', label: 'Compare' },
  { key: 'board', icon: '🏆', label: 'Board' },
];

export function BottomNav({ active, onChange }: { active: TabKey; onChange: (tab: TabKey) => void }) {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 flex border-t border-line bg-void/90 px-1.5 pt-2 backdrop-blur-md"
      style={{ paddingBottom: 'calc(8px + env(safe-area-inset-bottom))' }}
    >
      {TABS.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={`flex flex-1 flex-col items-center gap-0.5 rounded-xl px-0.5 py-1.5 ${
            active === t.key ? 'text-base' : 'text-ink-faint'
          }`}
        >
          <span className="text-lg">{t.icon}</span>
          <span className="text-[10px] font-semibold">{t.label}</span>
        </button>
      ))}
    </nav>
  );
}
