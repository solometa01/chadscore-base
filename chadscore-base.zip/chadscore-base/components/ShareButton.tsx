'use client';

import type { ChadProfile } from '@/types';
import { rankLabel } from '@/lib/score';

export function ShareButton({ profile }: { profile: ChadProfile }) {
  function share() {
    const text = `My ChadScore is ${profile.score}/100 — officially ranked ${rankLabel(profile.rank)} on @base 👀\n\nCheck your wallet's degen rating at chadscore.xyz`;
    const url = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(text);
    window.open(url, '_blank');
  }

  return (
    <button
      onClick={share}
      className="w-full rounded-xl border border-line bg-panel2 px-4 py-3.5 text-[15px] font-semibold"
    >
      🕊️ Share on X
    </button>
  );
}
