'use client';

import { BADGE_DEFS } from '@/lib/mockData';
import type { Badge } from '@/types';

export function BadgeGrid({ earned }: { earned: Badge[] }) {
  const earnedIds = new Set(earned.map((b) => b.id));

  return (
    <>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-base font-medium">Badges</h2>
        <span className="text-xs text-ink-faint">
          {earned.length}/{BADGE_DEFS.length}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-2.5">
        {BADGE_DEFS.map((b) => (
          <div
            key={b.id}
            className={`rounded-2xl border border-line bg-panel p-3 text-center ${earnedIds.has(b.id) ? '' : 'opacity-35'}`}
          >
            <div className="mb-1.5 text-2xl">{b.icon}</div>
            <div className="text-[10.5px] font-semibold leading-tight text-ink-dim">{b.name}</div>
          </div>
        ))}
      </div>
    </>
  );
}
