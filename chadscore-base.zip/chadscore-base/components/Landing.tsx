'use client';

import { ConnectButton } from '@rainbow-me/rainbowkit';

const FEATURES = ['🎯 Chad Score', '🤖 AI wallet review', '🕹️ XP + quests', '📡 Degen radar', '🏆 Leaderboard'];

export function Landing() {
  return (
    <div className="mx-auto max-w-lg px-5 pb-6 pt-12">
      <div className="mb-3.5 text-xs font-bold uppercase tracking-widest text-base">Base network · degen edition</div>
      <h1 className="mb-3.5 font-display text-4xl leading-[1.05] tracking-tight">
        How <span className="text-gold">chad</span>
        <br />
        is your wallet?
      </h1>
      <p className="mb-7 text-[15px] leading-relaxed text-ink-dim">
        Connect your Base wallet. Get scored 0–100 on age, txs, DeFi degeneracy, NFT bags and risk. Climb from Noob
        to Gigachad. Flex it on X.
      </p>
      <div className="mb-8 flex flex-wrap gap-2.5">
        {FEATURES.map((f) => (
          <div key={f} className="rounded-full border border-line bg-panel px-3 py-1.5 text-xs text-ink-dim">
            {f}
          </div>
        ))}
      </div>
      <div className="chad-connect-block">
        <ConnectButton.Custom>
          {({ openConnectModal }) => (
            <button
              onClick={openConnectModal}
              className="w-full rounded-xl bg-base px-4 py-4 text-[15px] font-semibold text-white active:scale-[0.98]"
            >
              Connect Base wallet
            </button>
          )}
        </ConnectButton.Custom>
      </div>
    </div>
  );
}
