'use client';

import type { WalletMetrics } from '@/types';

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

export function MetricsGrid({ metrics }: { metrics: WalletMetrics }) {
  const rows = [
    { label: 'Wallet age', value: `${metrics.age}d`, pct: clamp((metrics.age / 730) * 100, 0, 100), color: '#0052FF' },
    { label: 'Total txs', value: metrics.tx.toLocaleString(), pct: clamp((metrics.tx / 1200) * 100, 0, 100), color: '#0052FF' },
    { label: 'DeFi score', value: metrics.defi, pct: metrics.defi, color: '#00D67F' },
    { label: 'NFT holdings', value: metrics.nft, pct: clamp((metrics.nft / 50) * 100, 0, 100), color: '#FFB800' },
    { label: 'Risk score', value: metrics.risk, pct: metrics.risk, color: '#FF3B5C' },
    { label: 'Safety', value: 100 - metrics.risk, pct: 100 - metrics.risk, color: '#00D67F' },
  ];

  return (
    <div className="grid grid-cols-2 gap-2.5">
      {rows.map((r) => (
        <div key={r.label} className="rounded-2xl border border-line bg-panel p-3.5">
          <div className="mb-1.5 text-[11px] uppercase tracking-wide text-ink-faint">{r.label}</div>
          <div className="mb-2 font-display text-lg font-bold">{r.value}</div>
          <div className="h-1.5 overflow-hidden rounded-md bg-panel2">
            <div className="h-full rounded-md" style={{ width: `${r.pct}%`, background: r.color }} />
          </div>
        </div>
      ))}
    </div>
  );
}
