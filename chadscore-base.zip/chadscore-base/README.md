# ChadScore.xyz

A lightweight, degen-friendly Base wallet reputation app. Connect a Base wallet, get scored 0–100, climb from
Noob to Chad to Gigachad, run AI-generated quests, compare yourself to top wallets, and flex your score on X.

Built with Next.js (App Router) + TypeScript + Tailwind CSS + wagmi/RainbowKit.

## Stack

- **Next.js 14** (App Router) + **TypeScript**
- **Tailwind CSS** — dark, Base-blue/gold degen theme
- **wagmi v2** + **RainbowKit v2** — real wallet connect (Coinbase Wallet, MetaMask, WalletConnect, etc.) scoped to Base
- **Anthropic API** (`@anthropic-ai/sdk`) — powers the AI wallet review and AI quest generation, called from Next.js API routes so the key never reaches the client
- Everything else (score metrics, radar tokens, leaderboard, top Chad wallets) is mocked client-side, ready to be swapped for real data sources

## Getting started

```bash
npm install
cp .env.local.example .env.local
# fill in NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID and ANTHROPIC_API_KEY
npm run dev
```

Open http://localhost:3000. Connect a wallet on Base (or Base Sepolia for testing) and the app takes over.

### Environment variables

| Variable | Required? | Notes |
|---|---|---|
| `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` | Yes, for wallet connect to work | Free at https://cloud.walletconnect.com |
| `ANTHROPIC_API_KEY` | No | Without it, AI summary/quests gracefully fall back to canned copy |

## How the ChadScore is computed

`lib/score.ts` — a weighted 0–100 score from wallet age, tx count, DeFi activity, NFT holdings, and a risk score
(lower risk = safer). Rank tiers: Noob (<40), Chad (40–74), Gigachad (75+).

`lib/mockData.ts` derives deterministic mock metrics from the connected address (same wallet → same score on
reload) using a seeded PRNG. **Swap `generateMetrics()` for real reads** — an indexer (e.g. Dune, Covalent,
Basescan API) or your own subgraph — to make this production-accurate.

## Feature → file map

| Feature | Where |
|---|---|
| Wallet connect + profile | `app/providers.tsx`, `lib/wagmi.ts`, `hooks/useChadProfile.ts` |
| Chad Score + rank | `components/ChadScoreGauge.tsx`, `components/MetricsGrid.tsx` |
| AI wallet summary | `components/AiSummary.tsx` → `app/api/ai-summary/route.ts` |
| GameFi (XP/levels/badges) | `hooks/useGameState.ts`, `components/XpBar.tsx`, `components/BadgeGrid.tsx` |
| AI quests | `components/QuestPanel.tsx` → `app/api/ai-quests/route.ts` |
| Degen radar | `components/DegenRadar.tsx` |
| Smart compare | `components/SmartCompare.tsx` |
| Proof badge | `components/ProofBadge.tsx` (simulated mint — wire to a soulbound ERC-721/1155 contract for production) |
| Share on X | `components/ShareButton.tsx` |
| Leaderboard | `components/Leaderboard.tsx` |

## Notes / what's mocked vs real

- **Real**: wallet connection, network switching, address/account state (via wagmi + RainbowKit), the AI text
  generation (if `ANTHROPIC_API_KEY` is set).
- **Mocked**: wallet metrics (age/tx/DeFi/NFT/risk), the top-Chad leaderboard, and the Degen Radar token list.
  These are isolated in `lib/mockData.ts` so they're straightforward to replace with real on-chain/off-chain
  data sources without touching the UI layer.
- **Simulated**: the proof-badge "mint" generates a fake tx hash client-side. For a real non-transferable
  badge, deploy a soulbound token contract on Base and call it from `components/ProofBadge.tsx`.

## Scripts

```bash
npm run dev     # start dev server
npm run build   # production build
npm run start   # run the production build
npm run lint    # next lint
```
