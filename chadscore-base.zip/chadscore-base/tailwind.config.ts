import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ['class'],
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        void: '#080B12',
        panel: '#10151F',
        panel2: '#171E2C',
        line: '#232B3B',
        base: {
          DEFAULT: '#0052FF',
          dim: '#0052FF33',
        },
        gold: '#FFB800',
        chadgreen: '#00D67F',
        chadred: '#FF3B5C',
        ink: {
          DEFAULT: '#EAF0FF',
          dim: '#8B93A6',
          faint: '#5A6274',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'sans-serif'],
        body: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      borderRadius: {
        xl2: '20px',
      },
    },
  },
  plugins: [],
};

export default config;
