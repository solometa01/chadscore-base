import { NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

export const runtime = 'nodejs';

const SYSTEM_PROMPT =
  'Respond with ONLY valid JSON, no markdown code fences, no commentary before or after. ' +
  'Output an array of exactly 4 objects with keys: title (string, under 8 words), ' +
  'description (string, under 22 words, second person, crypto-native tone), ' +
  'xp (integer between 20 and 90), difficulty (one of easy, medium, hard). ' +
  'Tailor quests to the wallet profile described, referencing DeFi, NFTs, on-chain activity, ' +
  'or social/community engagement on Base.';

function parseQuestJson(text: string) {
  try {
    let t = text.trim();
    const fence = t.match(/```(?:json)?([\s\S]*?)```/);
    if (fence) t = fence[1].trim();
    const arr = JSON.parse(t);
    if (Array.isArray(arr) && arr.length > 0) return arr;
    return null;
  } catch {
    return null;
  }
}

export async function POST(req: Request) {
  const body = await req.json();
  const { metrics, score, rank } = body ?? {};

  if (!metrics || typeof score !== 'number' || !rank) {
    return NextResponse.json({ quests: null, error: 'invalid_payload' }, { status: 400 });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return NextResponse.json({ quests: null, error: 'no_api_key' }, { status: 200 });
  }

  try {
    const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 500,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: `Wallet: ChadScore ${score}/100, rank ${rank}, wallet age ${metrics.age} days, ${metrics.tx} txs, DeFi score ${metrics.defi}, ${metrics.nft} NFTs, risk ${metrics.risk}. A social scan of this user's X and Telegram found typical Base-degen engagement. Generate the 4 quests now.`,
        },
      ],
    });

    const text = message.content
      .map((block) => (block.type === 'text' ? block.text : ''))
      .join('\n')
      .trim();

    const quests = parseQuestJson(text);
    return NextResponse.json({ quests });
  } catch (err) {
    console.error('ai-quests error', err);
    return NextResponse.json({ quests: null, error: 'ai_unavailable' }, { status: 200 });
  }
}
