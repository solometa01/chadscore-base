import { NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

export const runtime = 'nodejs';

const SYSTEM_PROMPT =
  'You are ChadScore AI, a witty crypto-native assistant reviewing Base wallets for a degen audience. ' +
  'Write 2-3 short punchy sentences, under 55 words total, sentence case, light crypto slang ' +
  '(gm, wagmi, ape, diamond hands, ngmi) used naturally, not excessively. ' +
  'No markdown, no quotes, no hashtags.';

export async function POST(req: Request) {
  const body = await req.json();
  const { metrics, score, rank } = body ?? {};

  if (!metrics || typeof score !== 'number' || !rank) {
    return NextResponse.json({ text: null, error: 'invalid_payload' }, { status: 400 });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return NextResponse.json({ text: null, error: 'no_api_key' }, { status: 200 });
  }

  try {
    const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 300,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: `Wallet stats: age ${metrics.age} days, ${metrics.tx} total transactions, DeFi activity score ${metrics.defi}/100, ${metrics.nft} NFTs held, risk score ${metrics.risk}/100 (lower is safer). Overall ChadScore: ${score}/100, rank: ${rank}. Write the review.`,
        },
      ],
    });

    const text = message.content
      .map((block) => (block.type === 'text' ? block.text : ''))
      .join('\n')
      .trim();

    return NextResponse.json({ text: text || null });
  } catch (err) {
    console.error('ai-summary error', err);
    return NextResponse.json({ text: null, error: 'ai_unavailable' }, { status: 200 });
  }
}
