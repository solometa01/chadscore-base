'use client';

import { useState } from 'react';
import { useAccount } from 'wagmi';
import { Header } from '@/components/Header';
import { Landing } from '@/components/Landing';
import { BottomNav, type TabKey } from '@/components/BottomNav';
import { ChadScoreGauge } from '@/components/ChadScoreGauge';
import { MetricsGrid } from '@/components/MetricsGrid';
import { AiSummary } from '@/components/AiSummary';
import { BadgeGrid } from '@/components/BadgeGrid';
import { ProofBadge } from '@/components/ProofBadge';
import { ShareButton } from '@/components/ShareButton';
import { XpBar } from '@/components/XpBar';
import { QuestPanel } from '@/components/QuestPanel';
import { DegenRadar } from '@/components/DegenRadar';
import { SmartCompare } from '@/components/SmartCompare';
import { Leaderboard } from '@/components/Leaderboard';
import { useChadProfile } from '@/hooks/useChadProfile';
import { useGameState } from '@/hooks/useGameState';

function shortAddr(a: string) {
  return a.slice(0, 6) + '...' + a.slice(-4);
}

export default function Home() {
  const { isConnected } = useAccount();
  const profile = useChadProfile();
  const game = useGameState(profile);
  const [tab, setTab] = useState<TabKey>('score');

  return (
    <>
      <Header />

      {(!isConnected || !profile) && <Landing />}

      {isConnected && profile && (
        <div className="chad-scroll-safe">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div className="text-[13px] text-ink-faint">
              <span className="font-mono font-semibold text-ink">{shortAddr(profile.address)}</span>
              <span className="ml-2">Base mainnet · connected</span>
            </div>
          </div>

          <main className="mx-auto max-w-lg px-4 pb-2 pt-4">
            {tab === 'score' && (
              <div className="flex flex-col gap-5">
                <div className="rounded-2xl border border-line bg-panel p-4">
                  <ChadScoreGauge score={profile.score} rank={profile.rank} />
                </div>

                <section>
                  <div className="mb-3 flex items-center justify-between">
                    <h2 className="text-base font-medium">Wallet metrics</h2>
                    <span className="text-xs text-ink-faint">on-chain signal</span>
                  </div>
                  <MetricsGrid metrics={profile.metrics} />
                </section>

                <section>
                  <div className="mb-3">
                    <h2 className="text-base font-medium">AI wallet review</h2>
                  </div>
                  <AiSummary profile={profile} />
                </section>

                <section>
                  <BadgeGrid earned={game.badges} />
                </section>

                <section>
                  <div className="mb-3">
                    <h2 className="text-base font-medium">Proof badge</h2>
                  </div>
                  <ProofBadge profile={profile} minted={game.minted} onMint={game.mintBadge} />
                </section>

                <section>
                  <div className="mb-3">
                    <h2 className="text-base font-medium">Share your flex</h2>
                  </div>
                  <ShareButton profile={profile} />
                </section>
              </div>
            )}

            {tab === 'quests' && (
              <div className="flex flex-col gap-5">
                <XpBar level={game.level} xpIntoLevel={game.xpIntoLevel} xpPerLevel={game.xpPerLevel} />
                <QuestPanel
                  scanned={game.scanned}
                  scanning={game.scanning}
                  quests={game.quests}
                  onScan={game.scanSocials}
                  onComplete={game.completeQuest}
                />
              </div>
            )}

            {tab === 'radar' && <DegenRadar />}

            {tab === 'compare' && <SmartCompare profile={profile} />}

            {tab === 'board' && <Leaderboard profile={profile} level={game.level} />}
          </main>
        </div>
      )}

      {isConnected && profile && <BottomNav active={tab} onChange={setTab} />}
    </>
  );
}
